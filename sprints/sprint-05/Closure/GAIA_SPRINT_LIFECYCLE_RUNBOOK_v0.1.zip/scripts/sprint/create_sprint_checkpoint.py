from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
SPRINT = "sprint-06"
SPRINT_DIR = ROOT / "sprints" / SPRINT
BRANCH = "ING_3090"
FREEZE_TAG = "sprint-5-freeze"
START_TAG = "sprint-6-start"

def run(command):
    subprocess.run(command, cwd=ROOT, check=True)

def main():
    run(["git", "status", "--short"])
    run(["git", "rev-parse", "--verify", "HEAD"])
    run(["git", "rev-parse", f"origin/{BRANCH}"])

    run(["git", "tag", "-a", FREEZE_TAG, "-m", "GAIA Sprint 5 freeze checkpoint"])
    run(["git", "push", "origin", FREEZE_TAG])

    (SPRINT_DIR / "Stories").mkdir(parents=True, exist_ok=True)
    (SPRINT_DIR / "Checkpoints").mkdir(parents=True, exist_ok=True)
    (SPRINT_DIR / "Retrospectives").mkdir(parents=True, exist_ok=True)

    (SPRINT_DIR / "README.md").write_text(
        """# GAIA — Sprint 6

## Status

BOOTSTRAP — NOT YET PLANNED

## Inputs

- Sprint 5 frozen baseline
- E3 engineering checkpoint
- Architect / Project Knowledge / Senior Engineer triangulation
- Known Toolkit / HC-001 / 1070 blockers
- GAIA public/private boundary hypothesis

## Tracks

- Engineering Recovery
- Semantic / Governance Closure

## Rule

No implementation scope or architecture decision is implied by this bootstrap.
""",
        encoding="utf-8",
    )

    run(["git", "add", f"sprints/{SPRINT}"])
    run(["git", "commit", "-m", "chore(sprint-06): open sprint bootstrap checkpoint"])
    run(["git", "push", "origin", BRANCH])

    run(["git", "tag", "-a", START_TAG, "-m", "GAIA Sprint 6 opening checkpoint"])
    run(["git", "push", "origin", START_TAG])

    run(["git", "status", "--short"])
    run(["git", "rev-parse", "HEAD"])
    run(["git", "rev-parse", f"origin/{BRANCH}"])
    run(["git", "rev-parse", START_TAG])

if __name__ == "__main__":
    main()
