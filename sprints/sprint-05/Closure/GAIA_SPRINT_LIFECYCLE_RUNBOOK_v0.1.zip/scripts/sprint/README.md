# GAIA Sprint Lifecycle Runbook

The sprint lifecycle is checkpoint-driven.

## Creation sequence

1. Verify clean worktree.
2. Verify local HEAD.
3. Verify remote branch.
4. Tag previous sprint freeze.
5. Push previous sprint freeze tag.
6. Create new sprint structure.
7. Create bootstrap README.
8. Commit sprint bootstrap.
9. Push branch.
10. Tag sprint start.
11. Push sprint start tag.
12. Verify HEAD, remote HEAD and start tag.
13. Require clean worktree.

## Checkpoint model

Sprint N freeze
    ↓
Sprint N+1 bootstrap
    ↓
Sprint N+1 start tag
    ↓
planning
    ↓
implementation
    ↓
validation
    ↓
retrospective
    ↓
Sprint N+1 freeze

## Authority

The runbook performs repository mechanics only.

It does not decide:
- sprint scope;
- story ownership;
- architecture;
- acceptance;
- evidence status;
- implementation authority.

Those decisions remain outside the script.
