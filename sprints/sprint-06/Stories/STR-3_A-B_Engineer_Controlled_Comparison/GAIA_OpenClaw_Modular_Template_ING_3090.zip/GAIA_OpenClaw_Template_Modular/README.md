# GAIA OpenClaw Modular Template

Versioned, modular template for progressively deploying OpenClaw with GAIA.

Design:
  core runtime
      +
  target profile
      +
  optional modules
      +
  external secrets
      +
  environment/network profile

The first concrete target is ING_3090. The same structure is intended
to progress to ING_1070 and later hosts without cloning the whole stack.

This repository template contains placeholders and configuration
contracts. It does not claim that every module is currently supported
or enabled by OpenClaw.

## Progression

L0 — core smoke
L1 — local model + Engineer
L2 — Git/local repository
L3 — operator channel (Telegram)
L4 — project integrations (Linear/GitHub)
L5 — home automation (Home Assistant)
L6 — operator UI (Open WebUI)
L7 — optional browser/MCP
L8 — multi-agent/automation

Do not skip levels merely because configuration placeholders exist.

## Versioning

Pin the OpenClaw image/version in a target release profile.
Do not use `latest` for a reproducible release.

Recommended future layout:

releases/
  openclaw-<version>/
    manifest.env
    compose.yml

The current package provides templates for creating that release
without claiming a release has already been validated.

## Secret boundary

Real secrets must live outside Git. The template contains only names
and placeholders. A future deployment can point to a secret file,
Docker secrets, or another secret manager without changing the
module definitions.
