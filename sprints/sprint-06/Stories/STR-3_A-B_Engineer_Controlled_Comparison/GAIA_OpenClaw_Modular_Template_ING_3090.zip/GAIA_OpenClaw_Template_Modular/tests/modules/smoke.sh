#!/usr/bin/env bash
set -euo pipefail
echo "== OpenClaw smoke =="
docker ps --format '{{.Names}}' | grep -q '^gaia-openclaw-' || {
  echo "FAIL: OpenClaw container not running"; exit 1;
}
echo "PASS: container running"
