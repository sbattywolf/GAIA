#!/usr/bin/env bash
set -euo pipefail
echo "== OpenClaw modular target preflight =="

command -v docker >/dev/null || { echo "FAIL: docker missing"; exit 1; }
docker version >/dev/null || { echo "FAIL: docker unavailable"; exit 1; }
docker compose version

if command -v nvidia-smi >/dev/null; then
  echo "-- NVIDIA --"
  nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader
else
  echo "WARN: nvidia-smi not found"
fi

for p in /software /software/openclaw; do
  [ -e "$p" ] && echo "PRESENT $p" || echo "MISSING $p"
done
