# Release/versioning model

Use a release directory for each validated OpenClaw target release.

Example:

releases/
  openclaw-<version>-ing3090/
    manifest.env
    compose.yml
    checksums.txt
    README.md

Record:
- OpenClaw image digest/version;
- target profile;
- model/provider;
- enabled modules;
- host preflight result;
- GPU/runtime result;
- smoke/acceptance results.

A release is immutable once accepted. New changes create a new release.

Do not use `latest` for an accepted release.
