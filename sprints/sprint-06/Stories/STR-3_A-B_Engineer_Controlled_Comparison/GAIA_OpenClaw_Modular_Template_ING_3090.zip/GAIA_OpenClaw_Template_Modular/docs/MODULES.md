# Module model

Each module has four layers:

1. declaration — `config/modules/*.env.example`
2. runtime fragment — `docker/modules/*.yml`
3. capability implementation — native OpenClaw/plugin/skill where possible
4. acceptance test — `tests/modules/*`

A module is not considered active because its files exist.

Progression:
CORE -> MODEL -> GIT -> TELEGRAM -> LINEAR/GITHUB -> HOME ASSISTANT ->
OPEN WEBUI -> BROWSER/MCP -> MULTI-AGENT/AUTOMATION

Every module should record:
- enabled/disabled;
- secret dependencies;
- network dependencies;
- host dependencies;
- security impact;
- acceptance test;
- OpenClaw-native vs GAIA adapter classification.
