# Secret boundary

Template files contain variable names only.

Real secrets belong outside Git.

Candidate injection layers:
- external env file;
- Docker secrets;
- host secret manager;
- future deployment secret provider.

The chosen mechanism must be documented in the target release
manifest. Do not copy tokens into OpenClaw configuration files when
an environment/secret reference is supported.
