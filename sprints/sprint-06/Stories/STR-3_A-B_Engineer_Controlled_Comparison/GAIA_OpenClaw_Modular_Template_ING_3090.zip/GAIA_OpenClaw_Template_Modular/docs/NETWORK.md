# Network model

Default:
- Gateway loopback only.
- LAN disabled.
- VPN disabled.
- public ingress disabled.

Optional:
- explicit LAN bind + CIDR allowlist;
- explicit VPN bind + CIDR allowlist;
- UniFi firewall policy.

Do not assume LAN or VPN is trusted.
Do not mount NAS/fileshares unless a concrete requirement exists.
Do not expose the Gateway directly to the public Internet.
