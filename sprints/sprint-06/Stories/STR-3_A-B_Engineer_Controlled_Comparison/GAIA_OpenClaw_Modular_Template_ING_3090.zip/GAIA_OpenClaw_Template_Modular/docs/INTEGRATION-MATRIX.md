# Integration matrix

| Module | Default | First acceptance |
|---|---|---|
| Local Git | ON | read/status/diff/test |
| Ollama | ON | model response |
| Telegram | OFF | receive/reply |
| Linear | OFF | read issue |
| GitHub | OFF | read repository metadata |
| Home Assistant | OFF | read-only state |
| Open WebUI | OFF | local operator chat |
| Browser | OFF | only if benchmark requires |
| MCP | OFF | only if benchmark requires |
| Multi-agent | OFF | later |
| Automation | OFF | later |

The matrix is a progression plan, not proof that each capability is
supported by the pinned OpenClaw release.
