# Verified Sources

- GitHub authentication: https://docs.github.com/en/authentication
- Home Assistant authentication: https://www.home-assistant.io/docs/authentication/
- Open WebUI API keys: https://docs.openwebui.com/features/authentication-access/api-keys/
- Open WebUI model API: https://docs.openwebui.com/reference/api-endpoints/
- Linear API: https://linear.app/docs/api-and-webhooks
- Telegram bot tutorial: https://core.telegram.org/bots/tutorial
- Ollama Modelfile: https://docs.ollama.com/modelfile
- Docker GPU Compose: https://docs.docker.com/compose/how-tos/gpu-support/
- UniFi ZBF: https://help.ui.com/hc/en-us/articles/115003173168-Zone-Based-Firewalls-in-UniFi
