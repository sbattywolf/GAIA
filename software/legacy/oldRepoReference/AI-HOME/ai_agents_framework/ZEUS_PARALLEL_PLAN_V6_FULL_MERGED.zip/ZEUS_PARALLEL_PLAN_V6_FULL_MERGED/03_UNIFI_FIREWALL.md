# UniFi and Firewall Template

Sostituire i placeholder con VLAN/subnet/IP reali prima di applicare.

```text
ADMIN_CLIENTS -> ZEUS_EDGE: SSH 22, Open WebUI 3000, Glances 61208
ADMIN_CLIENTS -> ZEUS_LAB: SSH 22 e servizi lab espliciti
ZEUS_EDGE -> HOME_ASSISTANT: TCP 8123
HOME_ASSISTANT -> ZEUS_EDGE: Ollama 11434 e voice ports necessarie
ZEUS_EDGE -> ZEUS_LAB: deny oggi; futura job API soltanto
IOT -> ZEUS_EDGE/ZEUS_LAB: deny new connections
EXTERNAL -> ZEUS services: deny
```

Non fare affidamento soltanto su UFW per porte Docker pubblicate: bind a IP specifico + policy UniFi + firewall host.
