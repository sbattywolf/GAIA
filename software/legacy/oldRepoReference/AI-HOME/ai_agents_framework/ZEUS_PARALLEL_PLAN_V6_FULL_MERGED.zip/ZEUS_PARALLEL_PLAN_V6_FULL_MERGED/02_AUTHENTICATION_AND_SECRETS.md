# Authentication and Secrets

## Umano vs macchina

- Login umano: passkey/security key/TOTP/browser approval.
- Servizio headless: SSH key, API key o token dedicato e revocabile.

Non salvare TOTP seed, recovery code o chiavi private in Git.

## Per servizio

- GitHub: chiave SSH diversa per 1070 e 3090; `gh auth login` via browser. PAT fine-grained solo se necessario.
- Home Assistant: long-lived token di utente tecnico sulla 1070; token HA test sulla 3090.
- Open WebUI: API key diversa per istanza; `WEBUI_SECRET_KEY` diversa dalla API key.
- Telegram: bot production e test distinti.
- Linear: chiave scoped soltanto nella fase Linear.
- Zeus tools/mock: token distinti.
- Dispatcher: `ZEUS_JOB_TOKEN` è l'unico secret intenzionalmente uguale sui due endpoint, creato soltanto nella fase dispatcher.

## File

```text
.env                 non-segreto locale
.secrets.env         segreti locali
.env.example         template Git
.secrets.env.example template Git
```
