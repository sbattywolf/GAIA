# ZEUS Parallel Plan V6 — Full Merged Package

Questa è la versione unica e completa. Integra:

- architettura 1070/3090;
- Zeus Edge OBSERVE/READ_ONLY/SAFE_EXECUTE;
- Telegram, Ollama, Home Assistant e backlog;
- Open WebUI, prompt, model preset e tool OpenAPI;
- Docker Compose per entrambe le macchine;
- GitOps, inventory, export/import e backup;
- `.env` / `.secrets.env`;
- autenticazione GitHub SSH + 2FA/browser approval;
- token Home Assistant, Open WebUI, Linear e Telegram;
- firewall/UniFi template;
- GRUB/Wake-on-LAN;
- test e rollback.

## Ordine

1. `01_ARCHITECTURE.md`
2. `02_AUTHENTICATION_AND_SECRETS.md`
3. `03_UNIFI_FIREWALL.md`
4. `1070/00_1070_START_HERE.md`
5. `3090/00_3090_START_HERE.md`

## Stato iniziale obbligatorio

```text
ZEUS_RUNTIME_MODE=observe
```

I file `.env` e `.secrets.env` inclusi contengono soltanto placeholder e sono ignorati da Git. I template `.example` sono versionabili.
