# GRUB and Wake-on-LAN

WOL non distingue avvio automatico da pressione manuale. Strategia robusta:

```text
Default Ubuntu
WOL -> Ubuntu
Windows manuale -> selezione menu GRUB
```

Backup prima di modificare:

```bash
sudo cp -a /etc/default/grub /etc/default/grub.backup.$(date +%Y%m%d-%H%M%S)
grep -E '^menuentry ' /boot/grub/grub.cfg
```

Usare `GRUB_DEFAULT=saved`, quindi `grub-set-default` con entry Ubuntu esatta. `grub-reboot` può selezionare Windows per il solo boot successivo.
