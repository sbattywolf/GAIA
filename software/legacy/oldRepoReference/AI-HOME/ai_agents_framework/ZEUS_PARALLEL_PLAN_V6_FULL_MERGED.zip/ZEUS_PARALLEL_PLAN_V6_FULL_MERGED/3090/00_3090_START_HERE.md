# 3090 Start Here

1. Ubuntu + NVIDIA driver + `nvidia-smi`.
2. GitHub SSH key/gh browser login distinto.
3. Ollama nativo e `qwen2.5-coder:14b`.
4. VS Code, venv, pytest.
5. Configurare `.env`/`.secrets.env` solo lab.
6. Avviare HA test e mock tools.
7. Testare codice 1070 prima di promotion.
8. OpenClaw resta POC; non production.
