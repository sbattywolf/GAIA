#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/.." && pwd)"
ollama pull qwen2.5-coder:14b
ollama create zeus-coder:1 -f "$BASE/models/zeus-coder/Modelfile"
