import httpx
class HA:
 def __init__(self,url,token):self.url=url.rstrip('/');self.h={'Authorization':'Bearer '+token}
 async def summary(self,domain=None):
  async with httpx.AsyncClient(timeout=15) as c:r=await c.get(self.url+'/api/states',headers=self.h);r.raise_for_status()
  out=[]
  for x in r.json():
   eid=x.get('entity_id','');d=eid.split('.')[0] if '.' in eid else ''
   if domain and d!=domain:continue
   if d in {'light','binary_sensor','sensor','switch','climate'}:out.append(f"{x.get('attributes',{}).get('friendly_name',eid)}: {x.get('state')}")
  return '\n'.join(out[:50]) or 'Nessuna entità trovata.'
