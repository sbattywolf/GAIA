import os
from pathlib import Path
from telegram import Update
from telegram.ext import Application,CommandHandler,ContextTypes,MessageHandler,filters
from env_loader import load,require
from ollama_client import decide
from ha_client import HA
from storage import rid,now,log,backlog
BASE=Path(__file__).resolve().parent.parent;load(BASE)
TOKEN=require('TELEGRAM_BOT_TOKEN');CHAT=int(require('TELEGRAM_ALLOWED_CHAT_ID'));MODE=os.getenv('ZEUS_RUNTIME_MODE','observe')
MODEL=require('OLLAMA_MODEL');OLLAMA=require('OLLAMA_API_URL');ha=HA(require('HOME_ASSISTANT_BASE_URL'),require('HOME_ASSISTANT_TOKEN'));sessions={}
async def start(u:Update,c:ContextTypes.DEFAULT_TYPE):
 if u.effective_chat and u.effective_chat.id==CHAT:await u.message.reply_text(f'Zeus online: {MODE}')
async def message(u:Update,c:ContextTypes.DEFAULT_TYPE):
 if not u.effective_chat or u.effective_chat.id!=CHAT or not u.message or not u.message.text:return
 text=u.message.text.strip();d=await decide(text,MODEL,OLLAMA,sessions.get(CHAT,[])[-8:]);executed=False;response=d.response
 if MODE in {'read_only','safe_execute'} and d.tool=='ha_read':response=await ha.summary(d.arguments.get('domain'));executed=True
 rec={'schema_version':1,'request_id':rid(),'timestamp':now(),'message':text,'category':d.category,'action':d.action,'target':d.target,'tool':d.tool,'mode':MODE,'executed':executed,'response':response}
 log(rec)
 if d.target in {'BACKLOG','RTX_3090'}:backlog(rec)
 sessions.setdefault(CHAT,[]).extend([{'role':'user','content':text},{'role':'assistant','content':response}]);await u.message.reply_text(response)
def main():
 app=Application.builder().token(TOKEN).build();app.add_handler(CommandHandler('start',start));app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,message));app.run_polling(drop_pending_updates=True)
if __name__=='__main__':main()
