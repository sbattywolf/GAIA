import json
import httpx
from models import ZeusDecision

PROMPT = """Sei Zeus. Rispondi in italiano naturale. Produci solo JSON con response, category, action, target, risk_level, tool, arguments. Tool: none, ha_read, ha_light. Le letture HOME usano ha_read; le luci on/off usano ha_light; le richieste complesse hanno target BACKLOG o RTX_3090. Non inventare entity_id o risultati."""

async def decide(text, model, url, history):
    payload = {
        "model": model,
        "stream": False,
        "format": "json",
        "messages": [
            {"role": "system", "content": PROMPT},
            *history,
            {"role": "user", "content": text},
        ],
        "options": {"temperature": 0.2, "num_ctx": 4096},
    }
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(url, json=payload)
        response.raise_for_status()
    return ZeusDecision.model_validate(json.loads(response.json()["message"]["content"]))
