# 1070 Start Here

1. Backup vecchio bot e Compose.
2. Modificare `.env` e `.secrets.env`; mantenere `observe`.
3. Generare token interni differenti.
4. Creare long-lived token HA dedicato.
5. Pull/create `zeus-edge:1`.
6. Installare Python requirements.
7. Arrestare temporaneamente il vecchio bot.
8. Avviare Zeus foreground.
9. Verificare JSONL/backlog.
10. Solo dopo usare systemd; poi read-only; infine luci allowlisted.
