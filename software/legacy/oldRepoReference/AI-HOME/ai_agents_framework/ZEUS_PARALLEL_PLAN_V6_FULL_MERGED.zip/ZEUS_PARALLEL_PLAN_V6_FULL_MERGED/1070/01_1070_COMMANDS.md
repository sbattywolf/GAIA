# 1070 Commands

```bash
cd /home/sbatta/local-ai/Scripts
mkdir -p msi_1070/zeus_edge
cp -a /PERCORSO/ZEUS_PARALLEL_PLAN_V6_FULL_MERGED/1070/. msi_1070/zeus_edge/
cd msi_1070/zeus_edge
chmod 640 .env
chmod 600 .secrets.env
nano .env
nano .secrets.env
python3 ../../../../scripts/validate_local_config.py .
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m compileall app openapi_tools
sudo systemctl stop ha-telegram-agent
python app/telegram_agent.py
```
