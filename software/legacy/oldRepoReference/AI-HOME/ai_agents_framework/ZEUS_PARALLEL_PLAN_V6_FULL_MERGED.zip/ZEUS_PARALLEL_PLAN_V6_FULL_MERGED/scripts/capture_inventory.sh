#!/usr/bin/env bash
set -euo pipefail
OUT="${1:?Usage: capture_inventory.sh OUTPUT_DIR}"
mkdir -p "$OUT"
date --iso-8601=seconds > "$OUT/captured_at.txt"
cat /etc/os-release > "$OUT/os-release.txt"
uname -a > "$OUT/uname.txt"
lscpu > "$OUT/lscpu.txt"
free -h > "$OUT/memory.txt"
ip -br address > "$OUT/ip-addresses.txt"
ip route > "$OUT/ip-routes.txt"
nvidia-smi > "$OUT/nvidia-smi.txt" 2>&1 || true
docker version > "$OUT/docker-version.txt" 2>&1 || true
docker compose version > "$OUT/docker-compose-version.txt" 2>&1 || true
docker ps -a --format '{{json .}}' > "$OUT/docker-containers.jsonl" 2>&1 || true
docker images --digests --format '{{json .}}' > "$OUT/docker-images.jsonl" 2>&1 || true
ollama --version > "$OUT/ollama-version.txt" 2>&1 || true
ollama list > "$OUT/ollama-list.txt" 2>&1 || true
python3 --version > "$OUT/python-version.txt" 2>&1 || true
code --list-extensions --show-versions > "$OUT/vscode-extensions.txt" 2>&1 || true
