#!/usr/bin/env bash
set -euo pipefail
python3 - "${1:-32}" <<'PY'
import secrets,sys
print(secrets.token_urlsafe(int(sys.argv[1])))
PY
