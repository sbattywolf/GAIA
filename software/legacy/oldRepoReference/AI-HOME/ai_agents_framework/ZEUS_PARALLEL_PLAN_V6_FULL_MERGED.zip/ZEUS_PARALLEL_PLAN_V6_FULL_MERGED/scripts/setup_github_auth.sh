#!/usr/bin/env bash
set -euo pipefail
EMAIL="${1:?Usage: setup_github_auth.sh EMAIL HOST_SUFFIX}"
SUFFIX="${2:?Usage: setup_github_auth.sh EMAIL HOST_SUFFIX}"
KEY="$HOME/.ssh/id_ed25519_${SUFFIX}"
[ -f "$KEY" ] || ssh-keygen -t ed25519 -C "$EMAIL" -f "$KEY"
eval "$(ssh-agent -s)"
ssh-add "$KEY"
echo 'Add this PUBLIC key to GitHub:'
cat "$KEY.pub"
echo 'Then run: gh auth login && gh auth setup-git && ssh -T git@github.com'
