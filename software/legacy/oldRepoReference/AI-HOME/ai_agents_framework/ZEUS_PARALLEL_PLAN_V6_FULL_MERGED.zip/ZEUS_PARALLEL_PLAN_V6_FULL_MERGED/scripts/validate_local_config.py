from pathlib import Path
import sys

def parse(path):
 d={}
 for raw in Path(path).read_text(encoding='utf-8').splitlines():
  s=raw.strip()
  if s and not s.startswith('#') and '=' in s:
   k,v=s.split('=',1); d[k.strip()]=v.strip().strip('"').strip("'")
 return d

def ready(v): return bool(v) and not v.upper().startswith(('REPLACE_','TODO_','CHANGE_'))
base=Path(sys.argv[1] if len(sys.argv)>1 else '.')
e=parse(base/'.env'); s=parse(base/'.secrets.env')
reqe={'ZEUS_NODE_ROLE','ZEUS_RUNTIME_MODE','OLLAMA_API_URL','OLLAMA_MODEL'}
reqs={'TELEGRAM_BOT_TOKEN','TELEGRAM_ALLOWED_CHAT_ID','HOME_ASSISTANT_TOKEN','ZEUS_TOOLS_TOKEN','OPENWEBUI_SECRET_KEY'} if e.get('ZEUS_NODE_ROLE')=='edge' else {'OPENWEBUI_LAB_SECRET_KEY','ZEUS_MOCK_TOOLS_TOKEN'}
missing=[f'env:{k}' for k in sorted(reqe) if not ready(e.get(k,''))]+[f'secret:{k}' for k in sorted(reqs) if not ready(s.get(k,''))]
if missing:
 print('NOT READY; values hidden')
 for x in missing: print(x)
 raise SystemExit(1)
print('READY; active-phase values valid and hidden')
