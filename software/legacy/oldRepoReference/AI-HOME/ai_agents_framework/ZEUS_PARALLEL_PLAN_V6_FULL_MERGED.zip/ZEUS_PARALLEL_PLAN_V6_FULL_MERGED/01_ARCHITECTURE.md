# Architecture

```text
Channels (Telegram, Open WebUI, future HA Assist)
  -> Zeus Brain on 1070
  -> Structured Decision
  -> Policy
  -> HA read / allowlisted lights / backlog candidate
  -> future 3090 dispatcher
```

## 1070 — ZEUS EDGE

Runtime H24, unico assistente percepito dall'utente. Modello consigliato: `qwen3:8b`. Modalità progressive:

```text
observe -> read_only -> safe_execute
```

## 3090 — ZEUS LAB

Sviluppo, test, HA test, analisi log, POC OpenClaw e futuro worker. Ollama nativo con `qwen2.5-coder:14b`.

## Open WebUI

UI e laboratorio, non autorità centrale. Prompt e tool autorevoli restano nel repository.
